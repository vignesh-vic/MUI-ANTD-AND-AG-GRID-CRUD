import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import MuiJson from "./MuiJson.json";
// import Autocomplete from "@mui/material/Autocomplete";
// import TextField from "@mui/material/TextField";
import React, { useState, useEffect } from "react";
import { Button, Modal } from "antd";
import { AgGridReact } from "ag-grid-react"; // the AG Grid React Component
import "ag-grid-community/styles/ag-grid.css"; // Core grid CSS, always needed
import "ag-grid-community/styles/ag-theme-alpine.css"; // Optional theme CSS

function MuiCrud() {
  //add model
  const [open, setOpen] = useState(false);
  const showModal = () => {
    setOpen(true);
  };
  const handleOk = () => {
    setOpen(false);
  };
  const handleCancel = () => {
    setOpen(false);
  };

    //delete model
    const [opendel, setOpendel] = useState(false);
    const showModaldel = () => {
      setOpendel(true);
    };
    const handleOkdel = () => {
      setOpendel(false);
    };
    const handleCanceldel = () => {
      setOpendel(false);
    };
  

  //When button is 0, it indicates that you are in "add" mode. When button is 1, it means you are in "update" mode.
  const [changeButtonMode, setchangeButtonMode] = useState(0);

  //intial state
  const [userDetails, setUserDetails] = useState([]);
  const [deleteId, setDeleteId] = useState();
  //store id in the state to find id to replace to update values
  const [passingId, setPassingId] = useState();

   //inputfiled values
   const [inputDetails, setInputDetails] = useState([
    {
      Id: "",
      Name: "",
      Email: "",
      Phone: "",
      Colleage: "",
      Degree: "",
      Year: "",
      Batch: "",
    },
  ]);



//get input from onChange and set inputfields
const onHandleChange=(e)=>{
const {name,value}=e.target;
setInputDetails((prev)=>({
    ...prev,
    [name]:value
  }));
}

  //find the max id in the table
  const generateUniqueID = () => {
    const maxID = userDetails.reduce(
      (max, user) => (user.Id > max ? user.Id : max),0
    );
    return maxID + 1;
  };


  const [columDefs] = useState([
    { field: "Id" },
    { field: "Name" },
    { field: "Email" },
    { field: "Phone" },
    { field: "Colleage" },
    { field: "Degree" },
    { field: "Batch" },
    { field: "Action",
      cellRenderer: ({ data }) => {
        return (
          <button onClick={() => {showModal(); showModal1(data);setchangeButtonMode(1)}} className="bg-blue-400  w-[60px]">Edit </button>
        );
      },
    },
    { field: "Action",
      cellRenderer: ({ data }) => {
        return (
          <button onClick={() => {showModaldel();setDeleteId(data.Id)
          }} className="bg-red-400  w-[60px]">Delete </button>
        );
      },
    },
  ]);

  //defauldcoldefs
  const defaultCol = {
    sortable: true,
    editable: true,
    filter: true,
    resizable: true,
    flex: 5,
  };
  useEffect(() => {
    setUserDetails(MuiJson.Interns);
  }, []);
  //add user
  const onHandleSubmit = () => {
    const newId = generateUniqueID();
    // Create a new product object with the calculated ID and other details
    const pushData = [];
    pushData.unshift({
      Id: newId,
      Name: inputDetails.Name,
      Email: inputDetails.Email,
      Phone: inputDetails.Phone,
      Colleage: inputDetails.Colleage,
      Degree: inputDetails.Degree,
      Year: inputDetails.Year,
      Batch: inputDetails.Batch,
    });
    setUserDetails([...pushData, ...userDetails]);
    // Clear the input fields
    setInputDetails({
      Id: "",
      Name: "",
      Email: "",
      Phone: "",
      Colleage: "",
      Degree: "",
      Year: "",
      Batch: "",
    });
  };

      //edit button show datas
      const showModal1 = (resiveObj) => {
        console.log('sh',resiveObj)
          setInputDetails({
            Id: resiveObj.Id,
            Name: resiveObj.Name,
            Email: resiveObj.Email,
            Phone: resiveObj.Phone,
            Colleage: resiveObj.Colleage,
            Degree: resiveObj.Degree,
            Year: resiveObj.Year,
            Batch: resiveObj.Batch,
          });
        
        console.log('edit',inputDetails)

        setPassingId(resiveObj.Id);
      }
  // handleEditOk update interns
  const handleEditOk = (Id) => {

    const index = userDetails.findIndex((item) => item?.Id === Id);
    console.log('INDEX',index)

    if (index > -1) {
      userDetails[index] = {
        ...userDetails[index],
        Name: inputDetails.Name,
        Email: inputDetails?.Email,
        Colleage: inputDetails?.Colleage,
        Degree: inputDetails.Degree,
        Year: inputDetails?.Year,
        Batch: inputDetails?.Batch,
      };
      setUserDetails([...userDetails]);
    }
  };


;

    //delete button
    const onHandleDelte = (del) => {
      let deleteArr = userDetails.findIndex((value) => value.Id === del);
      setUserDetails((prev) => {
        const preData = [...prev];
        preData.splice(deleteArr, 1);
        return preData;
      });
    };
  return (
    <>
      <Button type="primary" onClick={()=>{showModal()}}>
        Add user
      </Button>
      <Modal
        open={open}
        title="Add Users"
        onOk={handleOk}
        onCancel={handleCancel}
        footer={[
          <Button key="back" onClick={handleCancel}>
            Cancel
          </Button>,
          <Button key="submit" type="primary" onClick={changeButtonMode === 0 ? () => {onHandleSubmit(); handleOk();} : () => {setchangeButtonMode(0);handleEditOk(passingId); handleOk();}
            }>
            {changeButtonMode === 0 ? "ADD" : "UPDATE"}
          </Button>,
        ]}
      >
        <input
          className="border-2 border-gray-600 w-24 h-10 rounded-md p-4"
          style={{ height: "30px", width: "360px", marginBottom: "6px" }}
          name="Name"
          value={inputDetails.Name}

          placeholder="Name"
          onChange={onHandleChange}
        />
        <input
          className="border-2 border-gray-600 w-24 h-10 rounded-md p-4"
          style={{ height: "30px", width: "360px", marginBottom: "6px" }}
          name="Email"
          placeholder="Email"
          value={inputDetails.Email}

          onChange={onHandleChange}

        />
        <input
          className="border-2 border-gray-600 w-24 h-10 rounded-md p-4"
          style={{ height: "30px", width: "360px", marginBottom: "6px" }}
          name="Phone"
          placeholder="Phone"
          value={inputDetails.Phone}

          onChange={onHandleChange}

        />
        <input
          className="border-2 border-gray-600 w-24 h-10 rounded-md p-4"
          style={{ height: "30px", width: "360px", marginBottom: "6px" }}
          name="Colleage"
          placeholder="Colleage"
          value={inputDetails.Colleage}

          onChange={onHandleChange}

        />
        <input
          className="border-2 border-gray-600 w-24 h-10 rounded-md p-4"
          style={{ height: "30px", width: "360px", marginBottom: "6px" }}
          name="Degree"
          placeholder="Degree"
          onChange={onHandleChange}
          value={inputDetails.Degree}


        />
        <input
          className="border-2 border-gray-600 w-24 h-10 rounded-md p-4"
          style={{ height: "30px", width: "360px", marginBottom: "6px" }}
          name="Batch"
          placeholder="Batch"
          value={inputDetails.Batch}

          onChange={onHandleChange}

        />
      </Modal>
      <div className="ag-theme-alpine" style={{ height: 800, width: 1200 }}>
        <AgGridReact
          rowData={userDetails}
          columnDefs={columDefs}
          defaultColDef={defaultCol}
        />
      
      <Modal
        title="Delete"
        open={opendel}
        onOk={()=>{handleOkdel();onHandleDelte(deleteId);
        }}
        onCancel={handleCanceldel}
      >
        <h3>{"Are you want to delete!"}</h3>
      </Modal>
      </div>
    </>
  );
}

export default MuiCrud;
